bl_info = {
    "name": "Professional Color Management",
    "author": "Dimona Patrick",
    "version": (1, 2),
    "blender": (4, 0, 0),
    "location": "Properties > Render > Professional Color Management",
    "description": "Professional color management tools with AI optimization",
    "category": "Render",
}

import bpy
import os
import numpy as np
from math import log, exp
import colorsys
from bpy.props import (
    StringProperty,
    FloatVectorProperty,
    EnumProperty,
    BoolProperty,
    FloatProperty,
    IntProperty
)
from bpy.types import (
    Panel,
    Operator,
    PropertyGroup
)

class AIColorEnhancer:
    """AI-based color enhancement system"""
    
    def __init__(self):
        self.content_profiles = {
            'INTERIOR': {
                'profile': 'AGX',
                'look': 'AGX_BASE',
                'exposure_bias': 0.2,
                'contrast_bias': 1.1,
                'saturation_bias': 1.0,
                'highlight_threshold': 0.92,
                'shadow_threshold': 0.08
            },
            'EXTERIOR': {
                'profile': 'AGX',
                'look': 'AGX_PUNCHY',
                'exposure_bias': -0.1,
                'contrast_bias': 1.2,
                'saturation_bias': 1.1,
                'highlight_threshold': 0.95,
                'shadow_threshold': 0.05
            },
            'CHARACTER': {
                'profile': 'AGX',
                'look': 'AGX_MED_HIGH',
                'exposure_bias': 0.0,
                'contrast_bias': 1.15,
                'saturation_bias': 1.05,
                'highlight_threshold': 0.90,
                'shadow_threshold': 0.10
            },
            'PRODUCT': {
                'profile': 'KHRONOS',
                'look': 'KRONOS_HIGH',
                'exposure_bias': 0.1,
                'contrast_bias': 1.25,
                'saturation_bias': 1.0,
                'highlight_threshold': 0.93,
                'shadow_threshold': 0.07
            },
            'VFX': {
                'profile': 'KHRONOS',
                'look': 'KRONOS_MED',
                'exposure_bias': 0.0,
                'contrast_bias': 1.3,
                'saturation_bias': 1.15,
                'highlight_threshold': 0.97,
                'shadow_threshold': 0.03
            }
        }

    def analyze_histogram(self, pixels):
        """Analyze image histogram for exposure and contrast"""
        try:
            if pixels.size == 0:
                return {
                    'shadows': 0.1,
                    'midtones': 0.5,
                    'highlights': 0.9,
                    'contrast_range': 0.8
                }
                
            hist, bins = np.histogram(pixels, bins=256, range=(0, 1))
            
            # Calculate histogram statistics
            total_pixels = np.sum(hist)
            if total_pixels == 0:
                return {
                    'shadows': 0.1,
                    'midtones': 0.5,
                    'highlights': 0.9,
                    'contrast_range': 0.8
                }
                
            cumsum = np.cumsum(hist) / total_pixels
            
            # Find key points in histogram
            shadows = np.searchsorted(cumsum, 0.1)
            midtones = np.searchsorted(cumsum, 0.5)
            highlights = np.searchsorted(cumsum, 0.9)
            
            return {
                'shadows': shadows / 255,
                'midtones': midtones / 255,
                'highlights': highlights / 255,
                'contrast_range': (highlights - shadows) / 255
            }
        except Exception as e:
            print(f"Error in histogram analysis: {str(e)}")
            return {
                'shadows': 0.1,
                'midtones': 0.5,
                'highlights': 0.9,
                'contrast_range': 0.8
            }

    def analyze_color_distribution(self, pixels):
        """Analyze color distribution and saturation"""
        try:
            if pixels.size == 0:
                return {
                    'saturation': 0.5,
                    'value': 0.5,
                    'hue_variance': 0.1
                }
                
            # Convert RGB to HSV for better color analysis
            hsv_pixels = np.array([colorsys.rgb_to_hsv(r, g, b) for r, g, b in pixels[:, :3]])
            
            saturation = float(np.mean(hsv_pixels[:, 1]))
            value = float(np.mean(hsv_pixels[:, 2]))
            hue_variance = float(np.var(hsv_pixels[:, 0]))
            
            return {
                'saturation': saturation,
                'value': value,
                'hue_variance': hue_variance
            }
        except Exception as e:
            print(f"Error in color distribution analysis: {str(e)}")
            return {
                'saturation': 0.5,
                'value': 0.5,
                'hue_variance': 0.1
            }

    def detect_content_type(self, scene_stats, pixels):
        """Detect content type based on scene analysis"""
        try:
            if pixels.size == 0:
                return 'INTERIOR' if not scene_stats['is_exterior'] else 'EXTERIOR'
                
            # Convert pixels to HSV for better analysis
            hsv_pixels = np.array([colorsys.rgb_to_hsv(r, g, b) for r, g, b in pixels[:, :3]])
            
            # Calculate key metrics
            avg_saturation = float(np.mean(hsv_pixels[:, 1]))
            avg_value = float(np.mean(hsv_pixels[:, 2]))
            value_std = float(np.std(hsv_pixels[:, 2]))
            
            # Decision tree for content type
            if scene_stats['is_exterior']:
                return 'EXTERIOR'
            elif avg_value < 0.3 and value_std > 0.2:
                return 'INTERIOR'
            elif avg_saturation > 0.6 and value_std < 0.15:
                return 'PRODUCT'
            elif 0.3 < avg_saturation < 0.6 and 0.4 < avg_value < 0.7:
                return 'CHARACTER'
            else:
                return 'VFX'
        except Exception as e:
            print(f"Error in content type detection: {str(e)}")
            return 'INTERIOR' if not scene_stats['is_exterior'] else 'EXTERIOR'

    def get_content_type_defaults(self, content_type):
        """Get default settings for content type"""
        profile = self.content_profiles.get(content_type, self.content_profiles['INTERIOR'])
        return {
            'suggested_profile': profile['profile'],
            'suggested_look': profile['look'],
            'exposure': 0.0 + profile['exposure_bias'],
            'contrast': 1.0 * profile['contrast_bias'],
            'saturation': 1.0 * profile['saturation_bias']
        }

    def optimize_settings(self, content_type, scene_stats, pixels):
        """Optimize color settings based on content analysis"""
        hist_analysis = self.analyze_histogram(pixels)
        color_analysis = self.analyze_color_distribution(pixels)
        profile = self.content_profiles.get(content_type, self.content_profiles['INTERIOR'])
        
        # Calculate optimal settings
        exposure = self._calculate_exposure(hist_analysis, profile)
        contrast = self._calculate_contrast(hist_analysis, profile)
        saturation = self._calculate_saturation(color_analysis, profile)
        
        # HDR optimization
        if scene_stats['has_hdr']:
            exposure *= 0.9
            contrast *= 1.1
        
        return {
            'exposure': exposure,
            'contrast': contrast,
            'saturation': saturation,
            'enable_highlight_recovery': scene_stats['has_hdr'],
            'suggested_profile': profile['profile'],
            'suggested_look': profile['look']
        }

    def _calculate_exposure(self, hist_analysis, profile):
        """Calculate optimal exposure compensation"""
        target_midtone = 0.5
        current_midtone = hist_analysis['midtones']
        
        exposure = log(target_midtone / current_midtone) * profile['exposure_bias']
        return max(-2.0, min(2.0, exposure))

    def _calculate_contrast(self, hist_analysis, profile):
        """Calculate optimal contrast"""
        contrast_range = hist_analysis['contrast_range']
        target_range = 0.7
        
        contrast = (target_range / contrast_range) * profile['contrast_bias']
        return max(0.8, min(1.5, contrast))

    def _calculate_saturation(self, color_analysis, profile):
        """Calculate optimal saturation"""
        current_saturation = color_analysis['saturation']
        target_saturation = 0.5
        
        saturation = (target_saturation / current_saturation) * profile['saturation_bias']
        return max(0.5, min(1.5, saturation))

def analyze_scene_content(context):
    """Analyze scene content with enhanced AI"""
    scene = context.scene
    ai_enhancer = AIColorEnhancer()
    settings = context.scene.prof_color_management
    
    # Initialize default analysis results
    scene_stats = {
        'brightness': 0.5,
        'contrast': 1.0,
        'color_range': 1.0,
        'has_hdr': any(mat.use_nodes for mat in bpy.data.materials if mat.node_tree),
        'is_exterior': any(light.type == 'SUN' for light in bpy.data.lights),
        'exposure': 0.0,
        'contrast': 1.0,
        'saturation': 1.0,
        'enable_highlight_recovery': False,
        'suggested_profile': 'AGX',
        'suggested_look': 'AGX_BASE'
    }
    
    try:
        # Use manual content type if not set to AUTO
        if settings.content_type != 'AUTO':
            content_type = settings.content_type
        else:
            content_type = 'INTERIOR'  # Default content type
        
        # Try to analyze render result if available
        if bpy.data.images.get('Render Result'):
            render = bpy.data.images['Render Result']
            if render.has_data and render.size[0] > 0 and render.size[1] > 0:
                pixels = np.array(render.pixels[:])
                if pixels.size > 0:
                    pixels = pixels.reshape(-1, 4)  # RGBA format
                    
                    # Calculate image statistics
                    scene_stats['brightness'] = float(np.mean(pixels[:, :3]))
                    scene_stats['contrast'] = float(np.std(pixels[:, :3]))
                    scene_stats['color_range'] = float(np.max(pixels[:, :3]) - np.min(pixels[:, :3]))
                    
                    # Auto-detect content type if set to AUTO
                    if settings.content_type == 'AUTO':
                        content_type = ai_enhancer.detect_content_type(scene_stats, pixels)
                    
                    # Get AI-enhanced settings based on content type
                    optimized_settings = ai_enhancer.optimize_settings(content_type, scene_stats, pixels)
                    scene_stats.update(optimized_settings)
        
        # Update settings based on content type even without render
        scene_stats.update(ai_enhancer.get_content_type_defaults(content_type))
        
    except Exception as e:
        print(f"Error analyzing scene content: {str(e)}")
    
    return scene_stats

def get_content_types():
    """Get available content type presets"""
    items = [
        ('AUTO', 'Auto Detect', 'Automatically detect optimal settings'),
        ('INTERIOR', 'Interior', 'Interior architectural visualization'),
        ('EXTERIOR', 'Exterior', 'Exterior architectural visualization'),
        ('CHARACTER', 'Character', 'Character rendering'),
        ('PRODUCT', 'Product', 'Product visualization'),
        ('VFX', 'VFX', 'Visual effects compositing'),
        ('ANIMATION', 'Animation', 'Animation output')
    ]
    return items

def get_output_profiles():
    """Get available ICC profiles"""
    items = [
        ('DEFAULT', 'Default sRGB', 'Standard sRGB color space'),
        ('AGX', 'AGX', 'AgX - Modern film-like look with natural contrast'),
        ('KHRONOS', 'Khronos PBR', 'Khronos PBR Neutral - High dynamic range with PBR accuracy'),
        ('REC709', 'Rec.709', 'HD video standard'),
        ('REC2020', 'Rec.2020', 'Ultra HD video standard'),
        ('ACES', 'ACES', 'Academy Color Encoding System'),
        ('CUSTOM', 'Custom', 'Custom ICC profile')
    ]
    return items

def get_agx_looks():
    """Get available AGX looks"""
    items = [
        ('NONE', 'None', 'No additional look'),
        ('AGX_PUNCHY', 'Punchy', 'AgX - Punchy contrast and saturation'),
        ('AGX_GREYSCALE', 'Greyscale', 'AgX - Greyscale'),
        ('AGX_HIGH', 'High Contrast', 'AgX - High Contrast'),
        ('AGX_MED_HIGH', 'Medium High', 'AgX - Medium High Contrast'),
        ('AGX_BASE', 'Base', 'AgX - Base Contrast'),
        ('AGX_MED_LOW', 'Medium Low', 'AgX - Medium Low Contrast'),
        ('AGX_LOW', 'Low', 'AgX - Low Contrast'),
        ('AGX_VERY_LOW', 'Very Low', 'AgX - Very Low Contrast')
    ]
    return items

def get_kronos_looks():
    """Get available Kronos looks"""
    items = [
        ('NONE', 'None', 'No additional look'),
        ('KRONOS_HIGH', 'High Contrast', 'High Contrast'),
        ('KRONOS_MED', 'Medium Contrast', 'Medium Contrast'),
        ('KRONOS_LOW', 'Low Contrast', 'Low Contrast')
    ]
    return items

class ColorManagementSettings(PropertyGroup):
    content_type: EnumProperty(
        name="Content Type",
        items=get_content_types(),
        default='AUTO',
        description="Type of content being rendered"
    )
    
    output_profile: EnumProperty(
        name="Output Profile",
        items=get_output_profiles(),
        default='AGX',
        description="Choose color output profile"
    )
    
    agx_look: EnumProperty(
        name="AGX Look",
        items=get_agx_looks(),
        default='AGX_BASE',
        description="Choose AGX look variant"
    )
    
    kronos_look: EnumProperty(
        name="Kronos Look",
        items=get_kronos_looks(),
        default='KRONOS_MED',
        description="Choose Kronos look variant"
    )
    
    custom_lut_path: StringProperty(
        name="Custom LUT Path",
        subtype='FILE_PATH',
        description="Path to custom LUT file"
    )
    
    exposure: FloatProperty(
        name="Exposure",
        default=0.0,
        min=-10.0,
        max=10.0,
        description="Scene exposure adjustment"
    )
    
    contrast: FloatProperty(
        name="Contrast",
        default=1.0,
        min=0.0,
        max=2.0,
        description="Output contrast"
    )
    
    saturation: FloatProperty(
        name="Saturation",
        default=1.0,
        min=0.0,
        max=2.0,
        description="Color saturation"
    )
    
    enable_highlight_recovery: BoolProperty(
        name="Highlight Recovery",
        default=True,
        description="Enable highlight recovery for HDR content"
    )
    
    enable_color_space_adaptation: BoolProperty(
        name="Color Space Adaptation",
        default=True,
        description="Enable automatic color space adaptation"
    )
    
    enable_ai_optimization: BoolProperty(
        name="AI Optimization",
        default=True,
        description="Enable AI-assisted color optimization"
    )
    
    bit_depth: EnumProperty(
        name="Output Bit Depth",
        items=[
            ('8', '8-bit', 'Standard 8-bit output'),
            ('16', '16-bit', 'High-quality 16-bit output'),
            ('32', '32-bit', 'Full HDR 32-bit output')
        ],
        default='16',
        description="Output bit depth"
    )

class RENDER_PT_professional_management(Panel):
    bl_label = "Professional Color Management"
    bl_idname = "RENDER_PT_professional_management"
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_context = "render"
    bl_options = {'DEFAULT_CLOSED'}
    
    def draw(self, context):
        layout = self.layout
        settings = context.scene.prof_color_management
        
        # AI Analysis and Optimization
        box = layout.box()
        box.label(text="AI Color Enhancement", icon='COLORSET_01_VEC')
        col = box.column(align=True)
        col.prop(settings, "enable_ai_optimization", text="Enable AI Optimization")
        col.prop(settings, "content_type")
        if settings.enable_ai_optimization:
            col.operator("render.analyze_and_optimize", icon='FILE_REFRESH')
        
        # Output Profile
        box = layout.box()
        box.label(text="Output Configuration", icon='OUTPUT')
        box.prop(settings, "output_profile")
        
        # Profile-specific settings
        if settings.output_profile == 'AGX':
            box.prop(settings, "agx_look")
        elif settings.output_profile == 'KHRONOS':
            box.prop(settings, "kronos_look")
        elif settings.output_profile == 'CUSTOM':
            box.prop(settings, "custom_lut_path")
        
        # Color Adjustments
        box = layout.box()
        box.label(text="Color Adjustments", icon='COLOR')
        col = box.column(align=True)
        col.prop(settings, "exposure")
        col.prop(settings, "contrast")
        col.prop(settings, "saturation")
        
        # Advanced Settings
        box = layout.box()
        box.label(text="Advanced Settings", icon='SETTINGS')
        box.prop(settings, "enable_highlight_recovery")
        box.prop(settings, "enable_color_space_adaptation")
        box.prop(settings, "bit_depth")
        
        # Apply Button
        layout.operator("render.apply_professional_color_management", icon='CHECKMARK')

class RENDER_OT_analyze_and_optimize(Operator):
    bl_idname = "render.analyze_and_optimize"
    bl_label = "Analyze and Optimize (AI)"
    bl_description = "Analyze scene content and optimize color settings using AI"
    
    def optimize_settings(self, context, analysis):
        settings = context.scene.prof_color_management
        
        # Apply AI-suggested settings
        settings.exposure = analysis.get('exposure', settings.exposure)
        settings.contrast = analysis.get('contrast', settings.contrast)
        settings.saturation = analysis.get('saturation', settings.saturation)
        settings.enable_highlight_recovery = analysis.get('enable_highlight_recovery', 
                                                        settings.enable_highlight_recovery)
        
        # Set suggested profile and look
        if 'suggested_profile' in analysis:
            settings.output_profile = analysis['suggested_profile']
        
        if 'suggested_look' in analysis:
            if analysis['suggested_profile'] == 'AGX':
                settings.agx_look = analysis['suggested_look']
            elif analysis['suggested_profile'] == 'KHRONOS':
                settings.kronos_look = analysis['suggested_look']
        
        return settings
    
    def execute(self, context):
        if not context.scene.prof_color_management.enable_ai_optimization:
            self.report({'WARNING'}, "AI Optimization is disabled")
            return {'CANCELLED'}
        
        analysis = analyze_scene_content(context)
        self.optimize_settings(context, analysis)
        
        self.report({'INFO'}, f"Scene analyzed and optimized for {context.scene.prof_color_management.content_type}")
        return {'FINISHED'}

class RENDER_OT_apply_professional_color_management(Operator):
    bl_idname = "render.apply_professional_color_management"
    bl_label = "Apply Color Management"
    bl_description = "Apply professional color management settings"
    
    def apply_agx_settings(self, context, settings):
        """Apply AGX color management settings"""
        scene = context.scene
        scene.view_settings.view_transform = 'AgX'
        
        # Map enum values to actual Blender look names
        agx_look_mapping = {
            'NONE': 'None',
            'AGX_PUNCHY': 'AgX - Punchy',
            'AGX_GREYSCALE': 'AgX - Greyscale',
            'AGX_HIGH': 'AgX - High Contrast',
            'AGX_MED_HIGH': 'AgX - Medium High Contrast',
            'AGX_BASE': 'AgX - Base Contrast',
            'AGX_MED_LOW': 'AgX - Medium Low Contrast',
            'AGX_LOW': 'AgX - Low Contrast',
            'AGX_VERY_LOW': 'AgX - Very Low Contrast'
        }
        
        # Set the look based on the mapping
        look_name = agx_look_mapping.get(settings.agx_look, 'AgX - Base Contrast')
        scene.view_settings.look = look_name
    
    def apply_kronos_settings(self, context, settings):
        """Apply Kronos color management settings"""
        scene = context.scene
        scene.view_settings.view_transform = 'Khronos PBR Neutral'
        
        # Map enum values to actual Blender look names
        kronos_look_mapping = {
            'NONE': 'None',
            'KRONOS_HIGH': 'High Contrast',
            'KRONOS_MED': 'Medium Contrast',
            'KRONOS_LOW': 'Low Contrast'
        }
        
        # Set the look based on the mapping
        look_name = kronos_look_mapping.get(settings.kronos_look, 'None')
        scene.view_settings.look = look_name
    
    def execute(self, context):
        scene = context.scene
        settings = scene.prof_color_management
        
        # Run AI optimization if enabled
        if settings.enable_ai_optimization:
            bpy.ops.render.analyze_and_optimize()
        
        # Set color management based on profile
        if settings.output_profile == 'AGX':
            self.apply_agx_settings(context, settings)
        elif settings.output_profile == 'KHRONOS':
            self.apply_kronos_settings(context, settings)
        elif settings.output_profile == 'ACES':
            scene.view_settings.view_transform = 'ACES'
            scene.view_settings.look = 'None'
        elif settings.output_profile == 'REC709':
            scene.view_settings.view_transform = 'Filmic'
            scene.view_settings.look = 'None'
        elif settings.output_profile == 'DEFAULT':
            scene.view_settings.view_transform = 'Standard'
            scene.view_settings.look = 'None'
        
        # Apply common settings
        scene.view_settings.exposure = settings.exposure
        scene.view_settings.gamma = settings.contrast
        scene.view_settings.use_curve_mapping = settings.enable_color_space_adaptation
        
        # Set render settings based on bit depth
        if settings.bit_depth == '32':
            scene.render.image_settings.file_format = 'OPEN_EXR'
            scene.render.image_settings.color_depth = '32'
        elif settings.bit_depth == '16':
            scene.render.image_settings.file_format = 'PNG'
            scene.render.image_settings.color_depth = '16'
        else:
            scene.render.image_settings.file_format = 'PNG'
            scene.render.image_settings.color_depth = '8'
        
        # Update the scene
        scene.update_tag()
        self.report({'INFO'}, "Color management settings applied successfully")
        return {'FINISHED'}

classes = (
    ColorManagementSettings,
    RENDER_PT_professional_management,
    RENDER_OT_apply_professional_color_management,
    RENDER_OT_analyze_and_optimize,
)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.prof_color_management = bpy.props.PointerProperty(type=ColorManagementSettings)

def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    del bpy.types.Scene.prof_color_management

if __name__ == "__main__":
    register()
